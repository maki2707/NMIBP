﻿
using System.Collections.Generic;

namespace SematicWeb.Models
{
    public class Home
    {

        public List<Movie> randomMovies { get; set; }

        public Stats Stats { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;

namespace SematicWeb.Models
{
    public class Search
    {
        public List<SearchResult> results { get; set; }
    }
}
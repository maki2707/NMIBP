﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SematicWeb.Models
{
    public interface SearchResult
    {

        string name { get; set; }
    }
}

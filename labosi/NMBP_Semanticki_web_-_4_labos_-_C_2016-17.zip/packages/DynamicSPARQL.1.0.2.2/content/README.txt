﻿DynamicSPARQL dynamically scaffolds SPARQL queries
Please visit project wiki pages https://github.com/Efimster/DynamicSPARQL/wiki  

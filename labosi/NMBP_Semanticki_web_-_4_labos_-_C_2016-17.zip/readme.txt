Imam dohvat 3 random filma, 4 podatka za statistiku, search po glumcu i naslovu filma. 

Ostalo ne radi jbg